# دليل التثبيت والتشغيل - نظام إدارة الموارد البشرية
# Installation and Setup Guide - HR Management System

## العربية

### نظرة عامة
هذا النظام مخصص لشركة بروش انترناشيونال لخدمات التنظيف العامة وإدارة المرافق. يوفر حلولاً شاملة لإدارة الموارد البشرية باللغة العربية مع دعم كامل للتخطيط من اليمين إلى اليسار (RTL).

### المتطلبات الأساسية
- Node.js (الإصدار 18 أو أحدث)
- pnpm (مدير الحزم المفضل)
- متصفح ويب حديث

### التثبيت

1. **تنزيل المشروع:**
   ```bash
   # إذا كنت تستخدم git
   git clone [repository-url]
   cd shadcn-ui
   
   # أو قم بفك ضغط الملف المضغوط
   unzip hr-system.zip
   cd hr-system
   ```

2. **تثبيت التبعيات:**
   ```bash
   pnpm install
   ```

3. **بدء الخادم المحلي:**
   ```bash
   pnpm run dev
   ```

4. **فتح المتصفح:**
   افتح المتصفح وانتقل إلى: `http://localhost:5173`

### بيانات تسجيل الدخول التجريبية
- **اسم المستخدم:** Admin
- **كلمة المرور:** admin123

### الميزات الرئيسية

#### 1. المصادقة والأمان
- نظام تسجيل دخول آمن
- إدارة المستخدمين مع صلاحيات مختلفة
- حفظ البيانات محلياً في localStorage

#### 2. واجهة المستخدم
- تصميم متجاوب يدعم جميع الأجهزة
- تخطيط RTL كامل للغة العربية
- نمط فاتح/داكن قابل للتبديل
- شريط جانبي قابل للطي

#### 3. إدارة الموظفين
- عرض قائمة الموظفين
- تفاصيل شاملة لكل موظف
- البحث والتصفية
- إدارة المعلومات الشخصية

#### 4. لوحة التحكم
- إحصائيات شاملة
- الأنشطة الأخيرة
- نظرة عامة على الأقسام
- إجراءات سريعة

#### 5. الإعدادات
- إدارة المستخدمين
- معلومات الشركة
- إحصائيات النظام

### هيكل البيانات
يستخدم النظام ملف `PROSH_DATA.json` الذي يحتوي على:
- بيانات الموظفين
- طلبات الإجازات
- معلومات الرواتب
- تقييمات الأداء

### البناء والنشر

1. **بناء المشروع للإنتاج:**
   ```bash
   pnpm run build
   ```

2. **معاينة النسخة المبنية:**
   ```bash
   pnpm run preview
   ```

### استكشاف الأخطاء

#### مشاكل شائعة:
- **خطأ في تثبيت التبعيات:** تأكد من إصدار Node.js المناسب
- **مشاكل في الخطوط:** تحقق من اتصال الإنترنت لتحميل خطوط جوجل
- **مشاكل في localStorage:** تأكد من تمكين JavaScript في المتصفح

### الدعم الفني
لأي مشاكل تقنية أو استفسارات، يرجى التواصل مع فريق التطوير.

---

## English

### Overview
This HR Management System is specifically designed for Prosh International for general cleaning services and facility management. It provides comprehensive Arabic language HR solutions with full Right-to-Left (RTL) layout support.

### Prerequisites
- Node.js (version 18 or newer)
- pnpm (preferred package manager)
- Modern web browser

### Installation

1. **Download the project:**
   ```bash
   # If using git
   git clone [repository-url]
   cd shadcn-ui
   
   # Or extract from zip file
   unzip hr-system.zip
   cd hr-system
   ```

2. **Install dependencies:**
   ```bash
   pnpm install
   ```

3. **Start development server:**
   ```bash
   pnpm run dev
   ```

4. **Open browser:**
   Navigate to: `http://localhost:5173`

### Demo Login Credentials
- **Username:** Admin
- **Password:** admin123

### Key Features

#### 1. Authentication & Security
- Secure login system
- User management with different roles
- Local data storage using localStorage

#### 2. User Interface
- Responsive design for all devices
- Complete RTL layout for Arabic
- Light/Dark theme toggle
- Collapsible sidebar navigation

#### 3. Employee Management
- Employee listing and details
- Comprehensive employee profiles
- Search and filtering capabilities
- Personal information management

#### 4. Dashboard
- Comprehensive statistics
- Recent activities
- Department overview
- Quick actions

#### 5. Settings
- User management
- Company information
- System statistics

### Data Structure
The system uses `PROSH_DATA.json` containing:
- Employee data
- Leave requests
- Payroll information
- Performance reviews

### Build and Deployment

1. **Build for production:**
   ```bash
   pnpm run build
   ```

2. **Preview production build:**
   ```bash
   pnpm run preview
   ```

### Troubleshooting

#### Common Issues:
- **Installation errors:** Ensure correct Node.js version
- **Font issues:** Check internet connection for Google Fonts
- **localStorage problems:** Ensure JavaScript is enabled

### Technical Support
For technical issues or inquiries, please contact the development team.

---

### تحديثات المستقبل / Future Updates
- إدارة الإجازات الكاملة / Complete leave management
- معالجة الرواتب / Payroll processing
- تقييمات الأداء / Performance reviews
- التقارير المتقدمة / Advanced reporting
- تكامل مع قاعدة البيانات السحابية / Cloud database integration

### الرخصة / License
هذا المشروع مرخص لشركة بروش انترناشيونال
This project is licensed for Prosh International Company.