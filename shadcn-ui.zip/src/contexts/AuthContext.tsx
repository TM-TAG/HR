import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: string;
  username: string;
  role: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const login = (username: string, password: string): boolean => {
    // Get users from localStorage or use default admin
    const users = JSON.parse(localStorage.getItem('hrUsers') || '[]');
    const defaultAdmin = { id: '1', username: 'Admin', password: 'admin123', role: 'admin' };
    
    // If no users exist, add default admin
    if (users.length === 0) {
      users.push(defaultAdmin);
      localStorage.setItem('hrUsers', JSON.stringify(users));
    }

    const foundUser = users.find((u: { id: string; username: string; password: string; role: string }) => u.username === username && u.password === password);
    
    if (foundUser) {
      const userSession = { id: foundUser.id, username: foundUser.username, role: foundUser.role };
      setUser(userSession);
      localStorage.setItem('currentUser', JSON.stringify(userSession));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  const value = {
    user,
    login,
    logout,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};