import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useSidebar } from '@/contexts/SidebarContext';
import ArabicHeader from '@/components/layout/ArabicHeader';
import ArabicSidebar from '@/components/layout/ArabicSidebar';
import ArabicDashboard from '@/components/dashboard/ArabicDashboard';
import ArabicEmployeeList from '@/components/employees/ArabicEmployeeList';
import ArabicSettings from '@/components/settings/ArabicSettings';
import LoginPage from '@/components/auth/LoginPage';

import ArabicDepartmentList from '@/components/departments/ArabicDepartmentList';
import ArabicLeaveManagement from '@/components/leaves/ArabicLeaveManagement';

const ArabicPayrollManagement = () => (
  <div className="p-8 text-center" dir="rtl">
    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">إدارة الرواتب</h2>
    <p className="text-gray-600 dark:text-gray-400">قريباً - معالجة الرواتب والمدفوعات</p>
  </div>
);

const ArabicPerformanceReviews = () => (
  <div className="p-8 text-center" dir="rtl">
    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">تقييم الأداء</h2>
    <p className="text-gray-600 dark:text-gray-400">قريباً - إدارة تقييمات الأداء</p>
  </div>
);

const ArabicReports = () => (
  <div className="p-8 text-center" dir="rtl">
    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">التقارير</h2>
    <p className="text-gray-600 dark:text-gray-400">قريباً - إنشاء وعرض التقارير</p>
  </div>
);

export default function ArabicHRApp() {
  const { isAuthenticated } = useAuth();
  const { isCollapsed } = useSidebar();
  const [activeTab, setActiveTab] = useState('dashboard');

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <ArabicDashboard />;
      case 'employees':
        return <ArabicEmployeeList />;
      case 'departments':
        return <ArabicDepartmentList />;
      case 'leaves':
        return <ArabicLeaveManagement />;
      case 'payroll':
        return <ArabicPayrollManagement />;
      case 'reviews':
        return <ArabicPerformanceReviews />;
      case 'reports':
        return <ArabicReports />;
      case 'settings':
        return <ArabicSettings />;
      default:
        return <ArabicDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="flex h-screen">
        <ArabicSidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <ArabicHeader />
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 dark:bg-gray-900">
            <div className={`container mx-auto px-6 py-8 transition-all duration-300 ${
              isCollapsed ? 'max-w-none' : 'max-w-7xl'
            }`}>
              {renderContent()}
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}