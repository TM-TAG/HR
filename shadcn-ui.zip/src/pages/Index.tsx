import HRApp from './HRApp';

export default function WelcomePage() {
  return <HRApp />;
}
