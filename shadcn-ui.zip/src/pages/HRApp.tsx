import { useState } from 'react';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import Dashboard from '@/components/dashboard/Dashboard';
import EmployeeList from '@/components/employees/EmployeeList';
import DepartmentList from '@/components/departments/DepartmentList';
import LeaveManagement from '@/components/leaves/LeaveManagement';
import PayrollManagement from '@/components/payroll/PayrollManagement';
import PerformanceReviews from '@/components/performance/PerformanceReviews';
import Reports from '@/components/reports/Reports';
import Settings from '@/components/settings/Settings';

export default function HRApp() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'employees':
        return <EmployeeList />;
      case 'departments':
        return <DepartmentList />;
      case 'leaves':
        return <LeaveManagement />;
      case 'payroll':
        return <PayrollManagement />;
      case 'reviews':
        return <PerformanceReviews />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex h-screen">
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header />
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
            <div className="container mx-auto px-6 py-8">
              {renderContent()}
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}