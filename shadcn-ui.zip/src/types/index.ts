export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  position: string;
  department: string;
  salary: number;
  hireDate: string;
  status: 'active' | 'inactive' | 'terminated';
  avatar?: string;
  address: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
}

export interface Department {
  id: string;
  name: string;
  description: string;
  manager: string;
  employeeCount: number;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  type: 'vacation' | 'sick' | 'personal' | 'maternity' | 'paternity';
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedDate: string;
  approvedBy?: string;
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  period: string;
  basicSalary: number;
  overtime: number;
  bonuses: number;
  deductions: number;
  netPay: number;
  status: 'pending' | 'processed' | 'paid';
}

export interface PerformanceReview {
  id: string;
  employeeId: string;
  employeeName: string;
  reviewPeriod: string;
  reviewer: string;
  overallRating: number;
  goals: string[];
  achievements: string[];
  areasForImprovement: string[];
  comments: string;
  status: 'draft' | 'submitted' | 'completed';
  createdDate: string;
}

export interface HRMetrics {
  totalEmployees: number;
  activeEmployees: number;
  pendingLeaves: number;
  pendingReviews: number;
  averageSalary: number;
  turnoverRate: number;
}