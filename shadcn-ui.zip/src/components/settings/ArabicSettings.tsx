import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Plus, Edit, Trash2, User, Shield, Users, Building } from 'lucide-react';
import { toast } from 'sonner';

interface User {
  id: string;
  username: string;
  password: string;
  role: string;
  createdAt: string;
}

export default function ArabicSettings() {
  const [users, setUsers] = useState<User[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    role: 'user'
  });

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = () => {
    const savedUsers = JSON.parse(localStorage.getItem('hrUsers') || '[]');
    if (savedUsers.length === 0) {
      const defaultAdmin = {
        id: '1',
        username: 'Admin',
        password: 'admin123',
        role: 'admin',
        createdAt: new Date().toISOString()
      };
      savedUsers.push(defaultAdmin);
      localStorage.setItem('hrUsers', JSON.stringify(savedUsers));
    }
    setUsers(savedUsers);
  };

  const handleAddUser = () => {
    if (!formData.username || !formData.password) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    const existingUser = users.find(user => user.username === formData.username);
    if (existingUser) {
      toast.error('اسم المستخدم موجود بالفعل');
      return;
    }

    const newUser: User = {
      id: Date.now().toString(),
      username: formData.username,
      password: formData.password,
      role: formData.role,
      createdAt: new Date().toISOString()
    };

    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem('hrUsers', JSON.stringify(updatedUsers));

    setFormData({ username: '', password: '', role: 'user' });
    setIsAddDialogOpen(false);
    toast.success('تم إضافة المستخدم بنجاح');
  };

  const handleEditUser = () => {
    if (!editingUser || !formData.username || !formData.password) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    const existingUser = users.find(user => 
      user.username === formData.username && user.id !== editingUser.id
    );
    if (existingUser) {
      toast.error('اسم المستخدم موجود بالفعل');
      return;
    }

    const updatedUsers = users.map(user =>
      user.id === editingUser.id
        ? { ...user, username: formData.username, password: formData.password, role: formData.role }
        : user
    );

    setUsers(updatedUsers);
    localStorage.setItem('hrUsers', JSON.stringify(updatedUsers));

    setEditingUser(null);
    setFormData({ username: '', password: '', role: 'user' });
    toast.success('تم تحديث المستخدم بنجاح');
  };

  const handleDeleteUser = (userId: string) => {
    if (users.length === 1) {
      toast.error('لا يمكن حذف آخر مستخدم في النظام');
      return;
    }

    const updatedUsers = users.filter(user => user.id !== userId);
    setUsers(updatedUsers);
    localStorage.setItem('hrUsers', JSON.stringify(updatedUsers));
    toast.success('تم حذف المستخدم بنجاح');
  };

  const getRoleBadge = (role: string) => {
    const roleMap = {
      admin: { label: 'مدير', variant: 'default' as const },
      user: { label: 'مستخدم', variant: 'secondary' as const },
      hr: { label: 'موارد بشرية', variant: 'outline' as const }
    };
    
    const roleInfo = roleMap[role as keyof typeof roleMap] || roleMap.user;
    return (
      <Badge variant={roleInfo.variant}>
        {roleInfo.label}
      </Badge>
    );
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">الإعدادات</h1>
          <p className="text-gray-600 dark:text-gray-400">إدارة إعدادات النظام والمستخدمين</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* System Statistics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              إحصائيات النظام
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">إجمالي المستخدمين</span>
              <Badge variant="outline">{users.length}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">المديرون</span>
              <Badge variant="outline">
                {users.filter(user => user.role === 'admin').length}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">المستخدمون العاديون</span>
              <Badge variant="outline">
                {users.filter(user => user.role === 'user').length}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Company Information */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              معلومات الشركة
            </CardTitle>
            <CardDescription>
              بيانات شركة بروش انترناشيونال
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium">اسم الشركة</Label>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  شركة بروش انترناشيونال
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">نوع النشاط</Label>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  لخدمات التنظيف العامة وإدارة المرافق
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">البلد</Label>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  الكويت
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">نوع الشركة</Label>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  شركة محدودة المسؤولية
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* User Management */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              إدارة المستخدمين
            </CardTitle>
            <CardDescription>
              إضافة وتعديل وحذف مستخدمي النظام
            </CardDescription>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => {
                setFormData({ username: '', password: '', role: 'user' });
                setEditingUser(null);
              }}>
                <Plus className="h-4 w-4 ml-2" />
                إضافة مستخدم
              </Button>
            </DialogTrigger>
            <DialogContent dir="rtl">
              <DialogHeader>
                <DialogTitle className="text-right">إضافة مستخدم جديد</DialogTitle>
                <DialogDescription className="text-right">
                  أدخل بيانات المستخدم الجديد
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="username">اسم المستخدم</Label>
                  <Input
                    id="username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    placeholder="أدخل اسم المستخدم"
                    className="text-right"
                  />
                </div>
                <div>
                  <Label htmlFor="password">كلمة المرور</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="أدخل كلمة المرور"
                    className="text-right"
                  />
                </div>
                <div>
                  <Label htmlFor="role">الصلاحية</Label>
                  <select
                    id="role"
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="w-full p-2 border rounded-md text-right bg-white dark:bg-gray-800"
                  >
                    <option value="user">مستخدم عادي</option>
                    <option value="hr">موارد بشرية</option>
                    <option value="admin">مدير</option>
                  </select>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleAddUser}>إضافة المستخدم</Button>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  إلغاء
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">اسم المستخدم</TableHead>
                  <TableHead className="text-right">الصلاحية</TableHead>
                  <TableHead className="text-right">تاريخ الإنشاء</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium text-right">
                      <div className="flex items-center gap-2 justify-end">
                        <span>{user.username}</span>
                        {user.role === 'admin' && <Shield className="h-4 w-4 text-blue-500" />}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      {getRoleBadge(user.role)}
                    </TableCell>
                    <TableCell className="text-right text-sm text-gray-600 dark:text-gray-400">
                      {new Date(user.createdAt).toLocaleDateString('ar-SA')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setEditingUser(user);
                                setFormData({
                                  username: user.username,
                                  password: user.password,
                                  role: user.role
                                });
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent dir="rtl">
                            <DialogHeader>
                              <DialogTitle className="text-right">تعديل المستخدم</DialogTitle>
                              <DialogDescription className="text-right">
                                تحديث بيانات المستخدم
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label htmlFor="edit-username">اسم المستخدم</Label>
                                <Input
                                  id="edit-username"
                                  value={formData.username}
                                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                                  className="text-right"
                                />
                              </div>
                              <div>
                                <Label htmlFor="edit-password">كلمة المرور</Label>
                                <Input
                                  id="edit-password"
                                  type="password"
                                  value={formData.password}
                                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                  className="text-right"
                                />
                              </div>
                              <div>
                                <Label htmlFor="edit-role">الصلاحية</Label>
                                <select
                                  id="edit-role"
                                  value={formData.role}
                                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                                  className="w-full p-2 border rounded-md text-right bg-white dark:bg-gray-800"
                                >
                                  <option value="user">مستخدم عادي</option>
                                  <option value="hr">موارد بشرية</option>
                                  <option value="admin">مدير</option>
                                </select>
                              </div>
                            </div>
                            <DialogFooter>
                              <Button onClick={handleEditUser}>حفظ التغييرات</Button>
                              <Button variant="outline" onClick={() => setEditingUser(null)}>
                                إلغاء
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>

                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="sm" disabled={users.length === 1}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent dir="rtl">
                            <AlertDialogHeader>
                              <AlertDialogTitle className="text-right">
                                تأكيد الحذف
                              </AlertDialogTitle>
                              <AlertDialogDescription className="text-right">
                                هل أنت متأكد من حذف المستخدم "{user.username}"؟ لا يمكن التراجع عن هذا الإجراء.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>إلغاء</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteUser(user.id)}>
                                حذف
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}