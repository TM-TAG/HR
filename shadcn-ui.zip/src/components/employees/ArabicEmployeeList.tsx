import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Search, Plus, Eye, Edit, Phone, Mail, MapPin, User } from 'lucide-react';
import { arabicEmployees } from '@/data/arabicData';

export default function ArabicEmployeeList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [employees] = useState(arabicEmployees);

  const filteredEmployees = employees.filter(employee =>
    employee.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: string) => {
    const statusMap = {
      active: { label: 'نشط', variant: 'default' as const },
      inactive: { label: 'غير نشط', variant: 'secondary' as const },
      terminated: { label: 'منتهي الخدمة', variant: 'destructive' as const }
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.active;
    return (
      <Badge variant={statusInfo.variant}>
        {statusInfo.label}
      </Badge>
    );
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">الموظفون</h1>
          <p className="text-gray-600 dark:text-gray-400">إدارة بيانات الموظفين</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 ml-2" />
          إضافة موظف جديد
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة الموظفين</CardTitle>
          <CardDescription>
            إجمالي الموظفين: {employees.length} موظف
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 space-x-reverse mb-6">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="البحث عن موظف..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 text-right"
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">الموظف</TableHead>
                  <TableHead className="text-right">المنصب</TableHead>
                  <TableHead className="text-right">القسم</TableHead>
                  <TableHead className="text-right">الراتب</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEmployees.map((employee) => (
                  <TableRow key={employee.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3 space-x-reverse">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-blue-500 text-white">
                            {employee.firstName[0]}{employee.lastName[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">
                            {employee.firstName} {employee.lastName}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            {employee.email}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium text-right">
                      {employee.position}
                    </TableCell>
                    <TableCell className="text-right">
                      {employee.department}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {employee.salary.toLocaleString()} د.ك
                    </TableCell>
                    <TableCell className="text-right">
                      {getStatusBadge(employee.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl" dir="rtl">
                            <DialogHeader>
                              <DialogTitle className="text-right">
                                تفاصيل الموظف
                              </DialogTitle>
                              <DialogDescription className="text-right">
                                معلومات شاملة عن الموظف
                              </DialogDescription>
                            </DialogHeader>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div className="space-y-4">
                                <div className="text-center">
                                  <Avatar className="h-20 w-20 mx-auto mb-4">
                                    <AvatarFallback className="bg-blue-500 text-white text-xl">
                                      {employee.firstName[0]}{employee.lastName[0]}
                                    </AvatarFallback>
                                  </Avatar>
                                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                                    {employee.firstName} {employee.lastName}
                                  </h3>
                                  <p className="text-gray-600 dark:text-gray-400">
                                    {employee.position}
                                  </p>
                                </div>
                                
                                <div className="space-y-3">
                                  <div className="flex items-center gap-3">
                                    <Mail className="h-4 w-4 text-gray-400" />
                                    <span className="text-sm">{employee.email}</span>
                                  </div>
                                  <div className="flex items-center gap-3">
                                    <Phone className="h-4 w-4 text-gray-400" />
                                    <span className="text-sm">{employee.phone}</span>
                                  </div>
                                  <div className="flex items-center gap-3">
                                    <MapPin className="h-4 w-4 text-gray-400" />
                                    <span className="text-sm">{employee.address}</span>
                                  </div>
                                </div>
                              </div>

                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                      القسم
                                    </label>
                                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                                      {employee.department}
                                    </p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                      الراتب الشهري
                                    </label>
                                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                                      {employee.salary.toLocaleString()} د.ك
                                    </p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                      تاريخ التوظيف
                                    </label>
                                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                                      {new Date(employee.hireDate).toLocaleDateString('ar-SA')}
                                    </p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                      الحالة
                                    </label>
                                    <div className="mt-1">
                                      {getStatusBadge(employee.status)}
                                    </div>
                                  </div>
                                </div>

                                <div>
                                  <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                                    جهة الاتصال في حالات الطوارئ
                                  </label>
                                  <div className="mt-2 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                    <div className="flex items-center gap-2 mb-1">
                                      <User className="h-4 w-4 text-gray-400" />
                                      <span className="text-sm font-medium">
                                        {employee.emergencyContact.name}
                                      </span>
                                    </div>
                                    <div className="flex items-center gap-2 mb-1">
                                      <Phone className="h-4 w-4 text-gray-400" />
                                      <span className="text-sm">
                                        {employee.emergencyContact.phone}
                                      </span>
                                    </div>
                                    <p className="text-xs text-gray-500">
                                      العلاقة: {employee.emergencyContact.relationship}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredEmployees.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">
                لم يتم العثور على موظفين
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}