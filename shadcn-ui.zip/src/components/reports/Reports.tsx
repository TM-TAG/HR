import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  BarChart3, 
  Download, 
  Users, 
  Calendar,
  DollarSign,
  TrendingUp,
  FileText,
  Eye
} from 'lucide-react';
import { employees, departments, leaveRequests, payrollRecords } from '@/data/mockData';

export default function Reports() {
  const reportTypes = [
    {
      id: 'employee-summary',
      title: 'Rapport des Employés',
      description: 'Vue d\'ensemble des employés par département et statut',
      icon: Users,
      category: 'RH'
    },
    {
      id: 'payroll-analysis',
      title: 'Analyse de Paie',
      description: 'Analyse des coûts salariaux et tendances',
      icon: DollarSign,
      category: 'Finance'
    },
    {
      id: 'leave-statistics',
      title: 'Statistiques des Congés',
      description: 'Utilisation des congés par département',
      icon: Calendar,
      category: 'RH'
    },
    {
      id: 'performance-trends',
      title: 'Tendances de Performance',
      description: 'Évolution des performances des équipes',
      icon: TrendingUp,
      category: 'Management'
    }
  ];

  const generateReport = (reportId: string) => {
    console.log('Generating report:', reportId);
  };

  const previewReport = (reportId: string) => {
    console.log('Previewing report:', reportId);
  };

  // Quick statistics for dashboard
  const quickStats = {
    totalEmployees: employees.length,
    activeEmployees: employees.filter(e => e.status === 'active').length,
    totalDepartments: departments.length,
    pendingLeaves: leaveRequests.filter(l => l.status === 'pending').length,
    totalPayroll: payrollRecords.reduce((acc, r) => acc + r.netPay, 0),
    avgSalary: Math.round(employees.reduce((acc, e) => acc + e.salary, 0) / employees.length)
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Rapports RH</h1>
          <p className="text-muted-foreground">
            Analysez vos données RH et générez des rapports détaillés
          </p>
        </div>
        <div className="flex space-x-2">
          <Select defaultValue="this-month">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="this-week">Cette semaine</SelectItem>
              <SelectItem value="this-month">Ce mois</SelectItem>
              <SelectItem value="this-quarter">Ce trimestre</SelectItem>
              <SelectItem value="this-year">Cette année</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Quick Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-blue-600" />
              <div>
                <p className="text-xs text-muted-foreground">Employés</p>
                <p className="text-lg font-bold">{quickStats.totalEmployees}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-green-600" />
              <div>
                <p className="text-xs text-muted-foreground">Actifs</p>
                <p className="text-lg font-bold">{quickStats.activeEmployees}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4 text-purple-600" />
              <div>
                <p className="text-xs text-muted-foreground">Départements</p>
                <p className="text-lg font-bold">{quickStats.totalDepartments}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-orange-600" />
              <div>
                <p className="text-xs text-muted-foreground">Congés</p>
                <p className="text-lg font-bold">{quickStats.pendingLeaves}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-green-600" />
              <div>
                <p className="text-xs text-muted-foreground">Masse Sal.</p>
                <p className="text-lg font-bold">{Math.round(quickStats.totalPayroll / 1000)}K€</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-blue-600" />
              <div>
                <p className="text-xs text-muted-foreground">Sal. Moy.</p>
                <p className="text-lg font-bold">{Math.round(quickStats.avgSalary / 1000)}K€</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Available Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Rapports Disponibles</CardTitle>
          <CardDescription>
            Sélectionnez un rapport à générer ou visualiser
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reportTypes.map((report) => {
              const Icon = report.icon;
              return (
                <Card key={report.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Icon className="h-5 w-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-lg">{report.title}</CardTitle>
                        <Badge variant="secondary" className="mt-1">
                          {report.category}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-sm text-muted-foreground mb-4">
                      {report.description}
                    </p>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => previewReport(report.id)}
                        className="flex-1"
                      >
                        <Eye className="mr-2 h-4 w-4" />
                        Aperçu
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => generateReport(report.id)}
                        className="flex-1"
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Générer
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Rapports Récents</CardTitle>
          <CardDescription>
            Historique des rapports générés
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { name: 'Rapport Mensuel - Juillet 2024', date: '2024-08-01', size: '2.3 MB', status: 'Terminé' },
              { name: 'Analyse Paie - Q2 2024', date: '2024-07-15', size: '1.8 MB', status: 'Terminé' },
              { name: 'Statistiques Congés - Juin 2024', date: '2024-07-01', size: '985 KB', status: 'Terminé' },
            ].map((report, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <FileText className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">{report.name}</p>
                    <p className="text-sm text-muted-foreground">
                      Généré le {new Date(report.date).toLocaleDateString('fr-FR')} • {report.size}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline">{report.status}</Badge>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}