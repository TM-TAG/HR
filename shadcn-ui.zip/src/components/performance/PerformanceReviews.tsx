import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Star, Plus, Eye, Edit, TrendingUp } from 'lucide-react';
import { performanceReviews } from '@/data/mockData';

export default function PerformanceReviews() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'default';
      case 'submitted': return 'secondary';
      case 'draft': return 'destructive';
      default: return 'secondary';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return 'Terminé';
      case 'submitted': return 'Soumis';
      case 'draft': return 'Brouillon';
      default: return status;
    }
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= rating
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-gray-300'
            }`}
          />
        ))}
        <span className="ml-2 text-sm text-muted-foreground">
          {rating}/5
        </span>
      </div>
    );
  };

  const stats = {
    total: performanceReviews.length,
    completed: performanceReviews.filter(r => r.status === 'completed').length,
    pending: performanceReviews.filter(r => r.status === 'draft').length,
    avgRating: performanceReviews.length > 0
      ? performanceReviews.reduce((acc, r) => acc + r.overallRating, 0) / performanceReviews.length
      : 0,
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Évaluations de Performance</h1>
          <p className="text-muted-foreground">
            Gérez les évaluations et le développement de vos employés
          </p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Nouvelle Évaluation
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Évaluations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">Cette période</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Terminées</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
            <p className="text-xs text-muted-foreground">Évaluations finalisées</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">En Cours</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.pending}</div>
            <p className="text-xs text-muted-foreground">À compléter</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Note Moyenne</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgRating.toFixed(1)}/5</div>
            <div className="flex items-center mt-1">
              {renderStars(stats.avgRating)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Évaluations Récentes</CardTitle>
          <CardDescription>
            Suivi des évaluations de performance des employés
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employé</TableHead>
                <TableHead>Période</TableHead>
                <TableHead>Évaluateur</TableHead>
                <TableHead>Note</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {performanceReviews.map((review) => (
                <TableRow key={review.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarFallback>
                          {review.employeeName.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <span className="font-medium">{review.employeeName}</span>
                    </div>
                  </TableCell>
                  <TableCell>{review.reviewPeriod}</TableCell>
                  <TableCell>{review.reviewer}</TableCell>
                  <TableCell>
                    {renderStars(review.overallRating)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={getStatusColor(review.status)}>
                      {getStatusLabel(review.status)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Répartition des Notes</CardTitle>
            <CardDescription>Distribution des évaluations par note</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[5, 4, 3, 2, 1].map(rating => {
              const count = performanceReviews.filter(r => Math.floor(r.overallRating) === rating).length;
              const percentage = performanceReviews.length > 0 ? (count / performanceReviews.length) * 100 : 0;
              return (
                <div key={rating} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {renderStars(rating)}
                    </div>
                    <span className="text-sm text-muted-foreground">{count} employés</span>
                  </div>
                  <Progress value={percentage} className="h-2" />
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Actions Recommandées</CardTitle>
            <CardDescription>Basées sur les évaluations récentes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <TrendingUp className="h-5 w-5 text-blue-500" />
                <span className="font-medium">Formations Suggérées</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Planifier des formations pour les employés ayant identifié des axes d'amélioration
              </p>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Star className="h-5 w-5 text-yellow-500" />
                <span className="font-medium">Reconnaissance</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Féliciter les employés avec d'excellentes évaluations
              </p>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Edit className="h-5 w-5 text-green-500" />
                <span className="font-medium">Plans de Développement</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Créer des plans personnalisés basés sur les objectifs fixés
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}