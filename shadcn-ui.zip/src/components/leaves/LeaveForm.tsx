import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { LeaveRequest } from '@/types';
import { employees } from '@/data/mockData';

interface LeaveFormProps {
  leave?: LeaveRequest | null;
  onClose: () => void;
}

export default function LeaveForm({ leave, onClose }: LeaveFormProps) {
  const [formData, setFormData] = useState({
    employeeId: leave?.employeeId || '',
    type: leave?.type || 'vacation',
    startDate: leave?.startDate || '',
    endDate: leave?.endDate || '',
    reason: leave?.reason || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Calculate days
    const start = new Date(formData.startDate);
    const end = new Date(formData.endDate);
    const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 3600 * 24)) + 1;
    
    const selectedEmployee = employees.find(emp => emp.id === formData.employeeId);
    
    const leaveData = {
      ...formData,
      days,
      employeeName: selectedEmployee ? `${selectedEmployee.firstName} ${selectedEmployee.lastName}` : '',
      status: 'pending' as const,
      submittedDate: new Date().toISOString().split('T')[0],
    };
    
    console.log('Leave request:', leaveData);
    onClose();
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="employeeId">Employé</Label>
        <Select
          value={formData.employeeId}
          onValueChange={(value) => handleInputChange('employeeId', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Sélectionner un employé" />
          </SelectTrigger>
          <SelectContent>
            {employees.filter(emp => emp.status === 'active').map(emp => (
              <SelectItem key={emp.id} value={emp.id}>
                {emp.firstName} {emp.lastName} - {emp.department}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="type">Type de congé</Label>
        <Select
          value={formData.type}
          onValueChange={(value) => handleInputChange('type', value)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="vacation">Congés payés</SelectItem>
            <SelectItem value="sick">Arrêt maladie</SelectItem>
            <SelectItem value="personal">Personnel</SelectItem>
            <SelectItem value="maternity">Maternité</SelectItem>
            <SelectItem value="paternity">Paternité</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="startDate">Date de début</Label>
          <Input
            id="startDate"
            type="date"
            value={formData.startDate}
            onChange={(e) => handleInputChange('startDate', e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="endDate">Date de fin</Label>
          <Input
            id="endDate"
            type="date"
            value={formData.endDate}
            onChange={(e) => handleInputChange('endDate', e.target.value)}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reason">Motif</Label>
        <Textarea
          id="reason"
          value={formData.reason}
          onChange={(e) => handleInputChange('reason', e.target.value)}
          placeholder="Expliquez la raison de cette demande de congé"
          rows={3}
          required
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Annuler
        </Button>
        <Button type="submit">
          {leave ? 'Modifier' : 'Soumettre'}
        </Button>
      </div>
    </form>
  );
}