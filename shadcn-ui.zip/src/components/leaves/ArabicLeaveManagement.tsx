import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Calendar, Plus, CheckCircle, XCircle, Clock } from 'lucide-react';
import { arabicLeaveRequests } from '@/data/arabicData';

export default function ArabicLeaveManagement() {
  const getStatusBadge = (status: string) => {
    const statusMap = {
      approved: { label: 'موافق عليها', variant: 'default' as const, icon: CheckCircle },
      pending: { label: 'قيد المراجعة', variant: 'secondary' as const, icon: Clock },
      rejected: { label: 'مرفوضة', variant: 'destructive' as const, icon: XCircle }
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.pending;
    const Icon = statusInfo.icon;
    
    return (
      <Badge variant={statusInfo.variant} className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {statusInfo.label}
      </Badge>
    );
  };

  const getTypeLabel = (type: string) => {
    const typeMap = {
      vacation: 'إجازة سنوية',
      sick: 'إجازة مرضية',
      personal: 'إجازة شخصية',
      maternity: 'إجازة أمومة',
      paternity: 'إجازة أبوة'
    };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">إدارة الإجازات</h1>
          <p className="text-gray-600 dark:text-gray-400">متابعة طلبات الإجازات وإدارتها</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 ml-2" />
          طلب إجازة جديد
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  إجمالي الطلبات
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {arabicLeaveRequests.length}
                </p>
              </div>
              <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full">
                <Calendar className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  قيد المراجعة
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {arabicLeaveRequests.filter(req => req.status === 'pending').length}
                </p>
              </div>
              <div className="bg-orange-100 dark:bg-orange-900 p-3 rounded-full">
                <Clock className="h-6 w-6 text-orange-600 dark:text-orange-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  موافق عليها
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {arabicLeaveRequests.filter(req => req.status === 'approved').length}
                </p>
              </div>
              <div className="bg-green-100 dark:bg-green-900 p-3 rounded-full">
                <CheckCircle className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Leave Requests Table */}
      <Card>
        <CardHeader>
          <CardTitle>طلبات الإجازات</CardTitle>
          <CardDescription>
            جميع طلبات الإجازات المقدمة من الموظفين
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">الموظف</TableHead>
                  <TableHead className="text-right">نوع الإجازة</TableHead>
                  <TableHead className="text-right">تاريخ البدء</TableHead>
                  <TableHead className="text-right">تاريخ الانتهاء</TableHead>
                  <TableHead className="text-right">عدد الأيام</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {arabicLeaveRequests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-medium text-right">
                      {request.employeeName}
                    </TableCell>
                    <TableCell className="text-right">
                      {getTypeLabel(request.type)}
                    </TableCell>
                    <TableCell className="text-right">
                      {new Date(request.startDate).toLocaleDateString('ar-SA')}
                    </TableCell>
                    <TableCell className="text-right">
                      {new Date(request.endDate).toLocaleDateString('ar-SA')}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {request.days} أيام
                    </TableCell>
                    <TableCell className="text-right">
                      {getStatusBadge(request.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {request.status === 'pending' && (
                          <>
                            <Button size="sm" variant="outline" className="bg-green-50 text-green-700 hover:bg-green-100">
                              موافقة
                            </Button>
                            <Button size="sm" variant="outline" className="bg-red-50 text-red-700 hover:bg-red-100">
                              رفض
                            </Button>
                          </>
                        )}
                        <Button size="sm" variant="ghost">
                          عرض
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}