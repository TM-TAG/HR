import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Users, Building2, Calendar, TrendingUp, DollarSign, AlertTriangle } from 'lucide-react';
import { employees, departments, leaveRequests, performanceReviews } from '@/data/mockData';

export default function Dashboard() {
  const stats = {
    totalEmployees: employees.length,
    activeEmployees: employees.filter(e => e.status === 'active').length,
    totalDepartments: departments.length,
    pendingLeaves: leaveRequests.filter(l => l.status === 'pending').length,
    avgSalary: Math.round(employees.reduce((acc, emp) => acc + emp.salary, 0) / employees.length),
    pendingReviews: performanceReviews.filter(r => r.status === 'draft').length
  };

  const departmentStats = departments.map(dept => ({
    name: dept.name,
    employees: employees.filter(emp => emp.department === dept.name).length,
    percentage: Math.round((employees.filter(emp => emp.department === dept.name).length / employees.length) * 100)
  }));

  const recentLeaves = leaveRequests.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employés</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalEmployees}</div>
            <p className="text-xs text-muted-foreground">
              {stats.activeEmployees} actifs
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Départements</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalDepartments}</div>
            <p className="text-xs text-muted-foreground">
              Équipes organisées
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Congés en attente</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingLeaves}</div>
            <p className="text-xs text-muted-foreground">
              À approuver
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Salaire moyen</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgSalary.toLocaleString()} €</div>
            <p className="text-xs text-muted-foreground">
              Par mois
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Répartition par département</CardTitle>
            <CardDescription>Distribution des employés par équipe</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {departmentStats.map(dept => (
              <div key={dept.name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{dept.name}</span>
                  <span className="text-sm text-muted-foreground">
                    {dept.employees} employés ({dept.percentage}%)
                  </span>
                </div>
                <Progress value={dept.percentage} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Leave Requests */}
        <Card>
          <CardHeader>
            <CardTitle>Demandes de congés récentes</CardTitle>
            <CardDescription>Dernières demandes soumises</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentLeaves.map(leave => (
                <div key={leave.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">{leave.employeeName}</p>
                    <p className="text-xs text-muted-foreground">
                      {leave.type} • {leave.days} jour(s)
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(leave.startDate).toLocaleDateString('fr-FR')} - {new Date(leave.endDate).toLocaleDateString('fr-FR')}
                    </p>
                  </div>
                  <Badge variant={
                    leave.status === 'approved' ? 'default' :
                    leave.status === 'pending' ? 'secondary' : 'destructive'
                  }>
                    {leave.status === 'approved' ? 'Approuvé' :
                     leave.status === 'pending' ? 'En attente' : 'Rejeté'}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Actions rapides</CardTitle>
          <CardDescription>Tâches importantes à traiter</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-orange-500" />
                <span className="font-medium">Congés à approuver</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {stats.pendingLeaves} demandes en attente
              </p>
            </div>

            <div className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-blue-500" />
                <span className="font-medium">Évaluations</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Période d'évaluation en cours
              </p>
            </div>

            <div className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-green-500" />
                <span className="font-medium">Nouveau employé</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Ajouter un membre d'équipe
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}