import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Building, Calendar, DollarSign, TrendingUp, Clock } from 'lucide-react';
import { arabicEmployees, arabicDepartments, arabicLeaveRequests, arabicPayrollRecords } from '@/data/arabicData';

export default function ArabicDashboard() {
  const totalEmployees = arabicEmployees.length;
  const activeEmployees = arabicEmployees.filter(emp => emp.status === 'active').length;
  const pendingLeaves = arabicLeaveRequests.filter(leave => leave.status === 'pending').length;
  const totalDepartments = arabicDepartments.length;
  const averageSalary = Math.round(arabicEmployees.reduce((sum, emp) => sum + emp.salary, 0) / totalEmployees);

  const stats = [
    {
      title: 'إجمالي الموظفين',
      value: totalEmployees,
      icon: Users,
      description: 'موظف نشط',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      title: 'الأقسام',
      value: totalDepartments,
      icon: Building,
      description: 'قسم فعال',
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      title: 'الإجازات المعلقة',
      value: pendingLeaves,
      icon: Calendar,
      description: 'بانتظار الموافقة',
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    },
    {
      title: 'متوسط الراتب',
      value: `${averageSalary} د.ك`,
      icon: DollarSign,
      description: 'شهرياً',
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    }
  ];

  const recentActivities = [
    {
      id: 1,
      action: 'طلب إجازة جديد',
      employee: 'محمد خالد السالم',
      time: 'منذ ساعتين',
      type: 'leave'
    },
    {
      id: 2,
      action: 'تم معالجة الراتب',
      employee: 'أحمد محمد علي',
      time: 'منذ 4 ساعات',
      type: 'payroll'
    },
    {
      id: 3,
      action: 'تقييم أداء مكتمل',
      employee: 'نور أحمد المطيري',
      time: 'أمس',
      type: 'review'
    },
    {
      id: 4,
      action: 'موظف جديد',
      employee: 'فاطمة أحمد الزهراني',
      time: 'منذ يومين',
      type: 'employee'
    }
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">لوحة التحكم</h1>
        <p className="text-gray-600 dark:text-gray-400">مرحباً بك في نظام إدارة الموارد البشرية</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {stat.title}
                    </p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {stat.value}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {stat.description}
                    </p>
                  </div>
                  <div className={`${stat.bgColor} p-3 rounded-full`}>
                    <Icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              الأنشطة الأخيرة
            </CardTitle>
            <CardDescription>
              آخر الأنشطة في النظام
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">
                      {activity.action}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {activity.employee}
                    </p>
                  </div>
                  <div className="text-left">
                    <Badge variant="outline" className="text-xs">
                      {activity.type === 'leave' && 'إجازة'}
                      {activity.type === 'payroll' && 'راتب'}
                      {activity.type === 'review' && 'تقييم'}
                      {activity.type === 'employee' && 'موظف'}
                    </Badge>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              الإجراءات السريعة
            </CardTitle>
            <CardDescription>
              الإجراءات الأكثر استخداماً
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <button className="p-4 text-center rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
                <Users className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">إضافة موظف</p>
              </button>
              <button className="p-4 text-center rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors">
                <Calendar className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">طلب إجازة</p>
              </button>
              <button className="p-4 text-center rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-colors">
                <DollarSign className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">معالجة راتب</p>
              </button>
              <button className="p-4 text-center rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-orange-500 hover:bg-orange-50 dark:hover:bg-orange-900/20 transition-colors">
                <FileText className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">إنشاء تقرير</p>
              </button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Overview */}
      <Card>
        <CardHeader>
          <CardTitle>نظرة عامة على الأقسام</CardTitle>
          <CardDescription>
            توزيع الموظفين حسب الأقسام
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {arabicDepartments.map((department) => (
              <div key={department.id} className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
                <h3 className="font-semibold text-gray-900 dark:text-white">
                  {department.name}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  {department.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-blue-600">
                    {department.employeeCount}
                  </span>
                  <span className="text-xs text-gray-500">موظف</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  المدير: {department.manager}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}