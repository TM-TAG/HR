import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Department } from '@/types';
import { employees } from '@/data/mockData';

interface DepartmentFormProps {
  department?: Department | null;
  onClose: () => void;
}

export default function DepartmentForm({ department, onClose }: DepartmentFormProps) {
  const [formData, setFormData] = useState({
    name: department?.name || '',
    description: department?.description || '',
    manager: department?.manager || '',
  });

  const availableManagers = employees.filter(emp => emp.status === 'active');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically save to database
    console.log('Department data:', formData);
    onClose();
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nom du département</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => handleInputChange('name', e.target.value)}
          placeholder="Ex: Développement, Marketing, RH"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => handleInputChange('description', e.target.value)}
          placeholder="Décrivez le rôle et les responsabilités de ce département"
          rows={3}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="manager">Manager</Label>
        <Select
          value={formData.manager}
          onValueChange={(value) => handleInputChange('manager', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Sélectionner un manager" />
          </SelectTrigger>
          <SelectContent>
            {availableManagers.map(emp => (
              <SelectItem key={emp.id} value={`${emp.firstName} ${emp.lastName}`}>
                {emp.firstName} {emp.lastName} - {emp.position}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onClose}>
          Annuler
        </Button>
        <Button type="submit">
          {department ? 'Modifier' : 'Créer'}
        </Button>
      </div>
    </form>
  );
}