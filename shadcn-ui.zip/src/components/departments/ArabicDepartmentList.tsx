import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Building, Users, Plus, Eye } from 'lucide-react';
import { arabicDepartments } from '@/data/arabicData';

export default function ArabicDepartmentList() {
  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">الأقسام</h1>
          <p className="text-gray-600 dark:text-gray-400">إدارة أقسام الشركة</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 ml-2" />
          إضافة قسم جديد
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {arabicDepartments.map((department) => (
          <Card key={department.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full">
                  <Building className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <Badge variant="outline">
                  {department.employeeCount} موظف
                </Badge>
              </div>
              <CardTitle className="text-xl text-right">{department.name}</CardTitle>
              <CardDescription className="text-right">
                {department.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">المدير</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {department.manager}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">عدد الموظفين</span>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-gray-400" />
                    <span className="font-medium text-gray-900 dark:text-white">
                      {department.employeeCount}
                    </span>
                  </div>
                </div>
                <div className="pt-2 border-t">
                  <Button variant="outline" className="w-full">
                    <Eye className="h-4 w-4 ml-2" />
                    عرض التفاصيل
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}