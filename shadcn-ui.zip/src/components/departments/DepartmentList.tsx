import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Plus, Users, Building2, Edit } from 'lucide-react';
import { departments, employees } from '@/data/mockData';
import { Department } from '@/types';
import DepartmentForm from './DepartmentForm';

export default function DepartmentList() {
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const getDepartmentEmployees = (deptName: string) => {
    return employees.filter(emp => emp.department === deptName);
  };

  const handleEdit = (department: Department) => {
    setSelectedDepartment(department);
    setIsFormOpen(true);
  };

  const handleAddNew = () => {
    setSelectedDepartment(null);
    setIsFormOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gestion des Départements</h1>
          <p className="text-muted-foreground">
            Organisez vos équipes par département
          </p>
        </div>
        <Button onClick={handleAddNew}>
          <Plus className="mr-2 h-4 w-4" />
          Nouveau Département
        </Button>
      </div>

      {/* Department Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departments.map((department) => {
          const deptEmployees = getDepartmentEmployees(department.name);
          return (
            <Card key={department.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Building2 className="h-5 w-5 text-blue-600" />
                    <CardTitle className="text-lg">{department.name}</CardTitle>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(department)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
                <CardDescription>{department.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Manager */}
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2">Manager</p>
                  <div className="flex items-center space-x-2">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="text-xs">
                        {department.manager.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm">{department.manager}</span>
                  </div>
                </div>

                {/* Employee Count */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{deptEmployees.length} employés</span>
                  </div>
                  <Badge variant="secondary">
                    {Math.round((deptEmployees.length / employees.length) * 100)}%
                  </Badge>
                </div>

                {/* Recent Employees */}
                {deptEmployees.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-2">Équipe</p>
                    <div className="flex -space-x-2">
                      {deptEmployees.slice(0, 4).map((emp) => (
                        <Avatar key={emp.id} className="h-6 w-6 border-2 border-white">
                          <AvatarFallback className="text-xs">
                            {emp.firstName[0]}{emp.lastName[0]}
                          </AvatarFallback>
                        </Avatar>
                      ))}
                      {deptEmployees.length > 4 && (
                        <div className="h-6 w-6 rounded-full bg-muted border-2 border-white flex items-center justify-center">
                          <span className="text-xs text-muted-foreground">
                            +{deptEmployees.length - 4}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Department Stats */}
                <div className="pt-2 border-t">
                  <div className="grid grid-cols-2 gap-2 text-center">
                    <div>
                      <p className="text-xs text-muted-foreground">Actifs</p>
                      <p className="text-sm font-medium">
                        {deptEmployees.filter(emp => emp.status === 'active').length}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Sal. Moyen</p>
                      <p className="text-sm font-medium">
                        {deptEmployees.length > 0 
                          ? Math.round(deptEmployees.reduce((acc, emp) => acc + emp.salary, 0) / deptEmployees.length).toLocaleString()
                          : 0
                        } €
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Department Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {selectedDepartment ? 'Modifier Département' : 'Nouveau Département'}
            </DialogTitle>
            <DialogDescription>
              {selectedDepartment 
                ? 'Modifiez les informations du département'
                : 'Créez un nouveau département pour organiser vos équipes'
              }
            </DialogDescription>
          </DialogHeader>
          <DepartmentForm
            department={selectedDepartment}
            onClose={() => setIsFormOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}