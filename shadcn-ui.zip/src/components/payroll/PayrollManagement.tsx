import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { DollarSign, TrendingUp, Calculator, FileText } from 'lucide-react';
import { payrollRecords } from '@/data/mockData';

export default function PayrollManagement() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'default';
      case 'processed': return 'secondary';
      case 'pending': return 'destructive';
      default: return 'secondary';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'paid': return 'Payé';
      case 'processed': return 'Traité';
      case 'pending': return 'En attente';
      default: return status;
    }
  };

  // Statistics
  const stats = {
    totalPayroll: payrollRecords.reduce((acc, record) => acc + record.netPay, 0),
    avgSalary: Math.round(payrollRecords.reduce((acc, record) => acc + record.netPay, 0) / payrollRecords.length),
    processed: payrollRecords.filter(r => r.status === 'processed' || r.status === 'paid').length,
    pending: payrollRecords.filter(r => r.status === 'pending').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gestion de la Paie</h1>
          <p className="text-muted-foreground">
            Gérez les salaires et les paiements de vos employés
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Calculator className="mr-2 h-4 w-4" />
            Calculer Paie
          </Button>
          <Button>
            <FileText className="mr-2 h-4 w-4" />
            Générer Rapport
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Masse Salariale</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalPayroll.toLocaleString()} €</div>
            <p className="text-xs text-muted-foreground">Ce mois</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Salaire Moyen</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgSalary.toLocaleString()} €</div>
            <p className="text-xs text-muted-foreground">Net mensuel</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Traités</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.processed}</div>
            <p className="text-xs text-muted-foreground">Bulletins générés</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">En Attente</CardTitle>
            <Calculator className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.pending}</div>
            <p className="text-xs text-muted-foreground">À traiter</p>
          </CardContent>
        </Card>
      </div>

      {/* Payroll Records */}
      <Card>
        <CardHeader>
          <CardTitle>Registre des Paies</CardTitle>
          <CardDescription>
            Détails des salaires pour la période en cours
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employé</TableHead>
                <TableHead>Période</TableHead>
                <TableHead>Salaire de Base</TableHead>
                <TableHead>Heures Sup.</TableHead>
                <TableHead>Primes</TableHead>
                <TableHead>Déductions</TableHead>
                <TableHead>Net à Payer</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payrollRecords.map((record) => (
                <TableRow key={record.id}>
                  <TableCell className="font-medium">{record.employeeName}</TableCell>
                  <TableCell>{record.period}</TableCell>
                  <TableCell>{record.basicSalary.toLocaleString()} €</TableCell>
                  <TableCell>{record.overtime.toLocaleString()} €</TableCell>
                  <TableCell>{record.bonuses.toLocaleString()} €</TableCell>
                  <TableCell>{record.deductions.toLocaleString()} €</TableCell>
                  <TableCell className="font-medium">{record.netPay.toLocaleString()} €</TableCell>
                  <TableCell>
                    <Badge variant={getStatusColor(record.status)}>
                      {getStatusLabel(record.status)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        Voir
                      </Button>
                      {record.status === 'pending' && (
                        <Button size="sm">
                          Traiter
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Payroll Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Répartition des Coûts</CardTitle>
            <CardDescription>Analyse des composantes salariales</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">Salaires de base</span>
              <span className="text-sm font-medium">
                {payrollRecords.reduce((acc, r) => acc + r.basicSalary, 0).toLocaleString()} €
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Heures supplémentaires</span>
              <span className="text-sm font-medium">
                {payrollRecords.reduce((acc, r) => acc + r.overtime, 0).toLocaleString()} €
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Primes</span>
              <span className="text-sm font-medium">
                {payrollRecords.reduce((acc, r) => acc + r.bonuses, 0).toLocaleString()} €
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Déductions</span>
              <span className="text-sm font-medium text-red-600">
                -{payrollRecords.reduce((acc, r) => acc + r.deductions, 0).toLocaleString()} €
              </span>
            </div>
            <hr />
            <div className="flex items-center justify-between font-semibold">
              <span>Total Net</span>
              <span>{stats.totalPayroll.toLocaleString()} €</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Actions Rapides</CardTitle>
            <CardDescription>Tâches de paie courantes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full justify-start" variant="outline">
              <Calculator className="mr-2 h-4 w-4" />
              Calculer les charges sociales
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <FileText className="mr-2 h-4 w-4" />
              Exporter les bulletins de paie
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <DollarSign className="mr-2 h-4 w-4" />
              Générer virement bancaire
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <TrendingUp className="mr-2 h-4 w-4" />
              Rapport fiscal mensuel
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}