import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Users,
  Building2,
  Calendar,
  CreditCard,
  TrendingUp,
  BarChart3,
  Home,
  Settings
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Tableau de bord', icon: Home },
  { id: 'employees', label: 'Employés', icon: Users },
  { id: 'departments', label: 'Départements', icon: Building2 },
  { id: 'leaves', label: 'Congés', icon: Calendar },
  { id: 'payroll', label: 'Paie', icon: CreditCard },
  { id: 'reviews', label: 'Évaluations', icon: TrendingUp },
  { id: 'reports', label: 'Rapports', icon: BarChart3 },
  { id: 'settings', label: 'Paramètres', icon: Settings },
];

export default function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  return (
    <div className="w-64 bg-white border-r border-gray-200 h-full">
      <div className="p-6">
        <h2 className="text-xl font-bold text-gray-800">RH Management</h2>
      </div>
      <nav className="px-4">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Button
              key={item.id}
              variant={activeTab === item.id ? 'default' : 'ghost'}
              className={cn(
                'w-full justify-start mb-1',
                activeTab === item.id
                  ? 'bg-blue-600 text-white hover:bg-blue-700'
                  : 'text-gray-700 hover:bg-gray-100'
              )}
              onClick={() => onTabChange(item.id)}
            >
              <Icon className="mr-3 h-4 w-4" />
              {item.label}
            </Button>
          );
        })}
      </nav>
    </div>
  );
}