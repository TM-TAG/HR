import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Home,
  Users,
  Building,
  Calendar,
  DollarSign,
  TrendingUp,
  FileText,
  Settings,
  ChevronRight,
  ChevronLeft,
  Menu,
} from 'lucide-react';
import { useSidebar } from '@/contexts/SidebarContext';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const navigationItems = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: Home },
  { id: 'employees', label: 'الموظفون', icon: Users },
  { id: 'departments', label: 'الأقسام', icon: Building },
  { id: 'leaves', label: 'الإجازات', icon: Calendar },
  { id: 'payroll', label: 'الرواتب', icon: DollarSign },
  { id: 'reviews', label: 'تقييم الأداء', icon: TrendingUp },
  { id: 'reports', label: 'التقارير', icon: FileText },
  { id: 'settings', label: 'الإعدادات', icon: Settings },
];

export default function ArabicSidebar({ activeTab, onTabChange }: SidebarProps) {
  const { isCollapsed, toggleSidebar } = useSidebar();

  return (
    <div 
      className={`bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
      dir="rtl"
    >
      {/* Header with Company Branding */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        {!isCollapsed && (
          <div className="flex flex-col">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white">
              شركة بروش انترناشيونال
            </h2>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              لخدمات التنظيف العامة وإدارة المرافق
            </p>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleSidebar}
          className="hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          {isCollapsed ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </Button>
      </div>

      {/* Company Logo Area */}
      {!isCollapsed && (
        <div className="flex items-center justify-center p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="bg-blue-600 p-4 rounded-lg">
            <Building className="h-8 w-8 text-white" />
          </div>
        </div>
      )}

      {isCollapsed && (
        <div className="flex items-center justify-center p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="bg-blue-600 p-2 rounded">
            <Building className="h-6 w-6 text-white" />
          </div>
        </div>
      )}

      {/* Navigation */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          <nav className="space-y-1">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <Button
                  key={item.id}
                  variant={isActive ? "secondary" : "ghost"}
                  className={`w-full justify-start text-right ${
                    isCollapsed ? 'px-2' : 'px-3'
                  } ${
                    isActive
                      ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                  onClick={() => onTabChange(item.id)}
                >
                  <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'justify-start'} w-full`}>
                    <Icon className={`h-5 w-5 ${isCollapsed ? '' : 'ml-3'}`} />
                    {!isCollapsed && (
                      <span className="text-sm font-medium">{item.label}</span>
                    )}
                  </div>
                </Button>
              );
            })}
          </nav>
        </div>
      </ScrollArea>

      {/* Footer */}
      {!isCollapsed && (
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
            نظام إدارة الموارد البشرية v1.0
          </div>
        </div>
      )}
    </div>
  );
}