import { Employee, Department, LeaveRequest, PayrollRecord, PerformanceReview } from '../types';

// This will be loaded from the PROSH_DATA.json file
export const loadArabicData = async () => {
  try {
    const response = await fetch('/data/PROSH_DATA.json');
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error loading Arabic data:', error);
    return null;
  }
};

// Sample Arabic employees data for شركة بروش انترناشيونال
export const arabicEmployees: Employee[] = [
  {
    id: '1',
    firstName: 'أحمد',
    lastName: 'محمد علي',
    email: 'ahmed.mohamed@prosh-international.com',
    phone: '+965 9999 1234',
    position: 'مدير عمليات التنظيف',
    department: 'العمليات',
    salary: 800,
    hireDate: '2023-01-15',
    status: 'active',
    address: 'مدينة الكويت، الكويت',
    emergencyContact: {
      name: 'فاطمة أحمد',
      phone: '+965 9999 5678',
      relationship: 'زوجة'
    }
  },
  {
    id: '2',
    firstName: 'سارة',
    lastName: 'عبد الله الحمد',
    email: 'sara.abdullah@prosh-international.com',
    phone: '+965 9999 2345',
    position: 'مسؤولة الموارد البشرية',
    department: 'الموارد البشرية',
    salary: 750,
    hireDate: '2022-03-10',
    status: 'active',
    address: 'حولي، الكويت',
    emergencyContact: {
      name: 'علي عبد الله',
      phone: '+965 9999 6789',
      relationship: 'أخ'
    }
  },
  {
    id: '3',
    firstName: 'محمد',
    lastName: 'خالد السالم',
    email: 'mohamed.khalid@prosh-international.com',
    phone: '+965 9999 3456',
    position: 'فني صيانة المرافق',
    department: 'الصيانة',
    salary: 600,
    hireDate: '2023-06-01',
    status: 'active',
    address: 'الفروانية، الكويت',
    emergencyContact: {
      name: 'نورا محمد',
      phone: '+965 9999 7890',
      relationship: 'زوجة'
    }
  },
  {
    id: '4',
    firstName: 'نور',
    lastName: 'أحمد المطيري',
    email: 'noor.ahmed@prosh-international.com',
    phone: '+965 9999 4567',
    position: 'مشرفة فريق التنظيف',
    department: 'العمليات',
    salary: 550,
    hireDate: '2022-11-20',
    status: 'active',
    address: 'الجهراء، الكويت',
    emergencyContact: {
      name: 'أحمد المطيري',
      phone: '+965 9999 8901',
      relationship: 'والد'
    }
  }
];

export const arabicDepartments: Department[] = [
  {
    id: '1',
    name: 'العمليات',
    description: 'قسم عمليات التنظيف وإدارة المرافق',
    manager: 'أحمد محمد علي',
    employeeCount: 25
  },
  {
    id: '2',
    name: 'الموارد البشرية',
    description: 'إدارة الموارد البشرية والتوظيف',
    manager: 'سارة عبد الله الحمد',
    employeeCount: 5
  },
  {
    id: '3',
    name: 'الصيانة',
    description: 'صيانة المعدات والمرافق',
    manager: 'محمد خالد السالم',
    employeeCount: 12
  },
  {
    id: '4',
    name: 'الإدارة',
    description: 'الإدارة العامة والتخطيط',
    manager: 'نور أحمد المطيري',
    employeeCount: 8
  }
];

export const arabicLeaveRequests: LeaveRequest[] = [
  {
    id: '1',
    employeeId: '1',
    employeeName: 'أحمد محمد علي',
    type: 'vacation',
    startDate: '2024-08-15',
    endDate: '2024-08-25',
    days: 8,
    reason: 'إجازة سنوية مع العائلة',
    status: 'approved',
    submittedDate: '2024-07-20',
    approvedBy: 'سارة عبد الله الحمد'
  },
  {
    id: '2',
    employeeId: '3',
    employeeName: 'محمد خالد السالم',
    type: 'sick',
    startDate: '2024-08-10',
    endDate: '2024-08-12',
    days: 2,
    reason: 'مرض',
    status: 'pending',
    submittedDate: '2024-08-09'
  },
  {
    id: '3',
    employeeId: '4',
    employeeName: 'نور أحمد المطيري',
    type: 'personal',
    startDate: '2024-09-01',
    endDate: '2024-09-03',
    days: 3,
    reason: 'ظروف شخصية',
    status: 'approved',
    submittedDate: '2024-08-01',
    approvedBy: 'سارة عبد الله الحمد'
  }
];

export const arabicPayrollRecords: PayrollRecord[] = [
  {
    id: '1',
    employeeId: '1',
    employeeName: 'أحمد محمد علي',
    period: '2024-07',
    basicSalary: 800,
    overtime: 50,
    bonuses: 100,
    deductions: 150,
    netPay: 800,
    status: 'paid'
  },
  {
    id: '2',
    employeeId: '2',
    employeeName: 'سارة عبد الله الحمد',
    period: '2024-07',
    basicSalary: 750,
    overtime: 0,
    bonuses: 75,
    deductions: 125,
    netPay: 700,
    status: 'paid'
  },
  {
    id: '3',
    employeeId: '3',
    employeeName: 'محمد خالد السالم',
    period: '2024-07',
    basicSalary: 600,
    overtime: 25,
    bonuses: 0,
    deductions: 100,
    netPay: 525,
    status: 'processed'
  }
];

export const arabicPerformanceReviews: PerformanceReview[] = [
  {
    id: '1',
    employeeId: '1',
    employeeName: 'أحمد محمد علي',
    reviewPeriod: '2024 الربع الأول',
    reviewer: 'سارة عبد الله الحمد',
    overallRating: 4.5,
    goals: ['تحسين كفاءة العمليات', 'تدريب الفرق الجديدة', 'تطوير إجراءات السلامة'],
    achievements: ['زيادة الكفاءة بنسبة 30%', 'تدريب 5 موظفين جدد', 'تقليل الحوادث بنسبة 50%'],
    areasForImprovement: ['التواصل مع الإدارة العليا', 'استخدام التكنولوجيا'],
    comments: 'أداء ممتاز في إدارة العمليات. يحتاج إلى تطوير مهارات التواصل.',
    status: 'completed',
    createdDate: '2024-07-01'
  },
  {
    id: '2',
    employeeId: '4',
    employeeName: 'نور أحمد المطيري',
    reviewPeriod: '2024 الربع الأول',
    reviewer: 'سارة عبد الله الحمد',
    overallRating: 4.2,
    goals: ['تحسين جودة التنظيف', 'إدارة الفريق بكفاءة', 'تقليل الشكاوى'],
    achievements: ['تحسين جودة الخدمة بنسبة 25%', 'تدريب الفريق على معايير جديدة', 'تقليل الشكاوى بنسبة 40%'],
    areasForImprovement: ['إدارة الوقت', 'التعامل مع الضغط'],
    comments: 'أداء جيد جداً في الإشراف. تحتاج إلى تطوير مهارات إدارة الوقت.',
    status: 'completed',
    createdDate: '2024-07-01'
  }
];