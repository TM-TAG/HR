import { Employee, Department, LeaveRequest, PayrollRecord, PerformanceReview } from '../types';

export const employees: Employee[] = [
  {
    id: '1',
    firstName: 'Jean',
    lastName: 'Dupont',
    email: 'jean.dupont@company.com',
    phone: '+33 1 23 45 67 89',
    position: 'Développeur Senior',
    department: 'IT',
    salary: 55000,
    hireDate: '2022-01-15',
    status: 'active',
    address: '123 Rue de la République, Paris',
    emergencyContact: {
      name: 'Marie Dupont',
      phone: '+33 6 12 34 56 78',
      relationship: 'Épouse'
    }
  },
  {
    id: '2',
    firstName: 'Marie',
    lastName: 'Martin',
    email: 'marie.martin@company.com',
    phone: '+33 1 34 56 78 90',
    position: 'Responsable RH',
    department: 'HR',
    salary: 48000,
    hireDate: '2021-03-10',
    status: 'active',
    address: '456 Avenue des Champs, Lyon',
    emergencyContact: {
      name: 'Pierre Martin',
      phone: '+33 6 23 45 67 89',
      relationship: 'Mari'
    }
  },
  {
    id: '3',
    firstName: 'Pierre',
    lastName: 'Durand',
    email: 'pierre.durand@company.com',
    phone: '+33 1 45 67 89 01',
    position: 'Comptable',
    department: 'Finance',
    salary: 42000,
    hireDate: '2023-06-01',
    status: 'active',
    address: '789 Boulevard Saint-Michel, Marseille',
    emergencyContact: {
      name: 'Sophie Durand',
      phone: '+33 6 34 56 78 90',
      relationship: 'Sœur'
    }
  },
  {
    id: '4',
    firstName: 'Sophie',
    lastName: 'Bernard',
    email: 'sophie.bernard@company.com',
    phone: '+33 1 56 78 90 12',
    position: 'Chef de Projet',
    department: 'Operations',
    salary: 52000,
    hireDate: '2020-11-20',
    status: 'active',
    address: '321 Rue de Rivoli, Toulouse',
    emergencyContact: {
      name: 'Marc Bernard',
      phone: '+33 6 45 67 89 01',
      relationship: 'Père'
    }
  }
];

export const departments: Department[] = [
  {
    id: '1',
    name: 'IT',
    description: 'Département informatique et développement',
    manager: 'Jean Dupont',
    employeeCount: 8
  },
  {
    id: '2',
    name: 'HR',
    description: 'Ressources humaines',
    manager: 'Marie Martin',
    employeeCount: 3
  },
  {
    id: '3',
    name: 'Finance',
    description: 'Comptabilité et finance',
    manager: 'Pierre Durand',
    employeeCount: 5
  },
  {
    id: '4',
    name: 'Operations',
    description: 'Opérations et gestion de projet',
    manager: 'Sophie Bernard',
    employeeCount: 6
  }
];

export const leaveRequests: LeaveRequest[] = [
  {
    id: '1',
    employeeId: '1',
    employeeName: 'Jean Dupont',
    type: 'vacation',
    startDate: '2024-08-15',
    endDate: '2024-08-25',
    days: 8,
    reason: 'Vacances d\'été en famille',
    status: 'approved',
    submittedDate: '2024-07-20',
    approvedBy: 'Marie Martin'
  },
  {
    id: '2',
    employeeId: '3',
    employeeName: 'Pierre Durand',
    type: 'sick',
    startDate: '2024-08-10',
    endDate: '2024-08-12',
    days: 2,
    reason: 'Grippe',
    status: 'pending',
    submittedDate: '2024-08-09'
  },
  {
    id: '3',
    employeeId: '4',
    employeeName: 'Sophie Bernard',
    type: 'personal',
    startDate: '2024-09-01',
    endDate: '2024-09-03',
    days: 3,
    reason: 'Déménagement',
    status: 'approved',
    submittedDate: '2024-08-01',
    approvedBy: 'Marie Martin'
  }
];

export const payrollRecords: PayrollRecord[] = [
  {
    id: '1',
    employeeId: '1',
    employeeName: 'Jean Dupont',
    period: '2024-07',
    basicSalary: 4583,
    overtime: 200,
    bonuses: 500,
    deductions: 1200,
    netPay: 4083,
    status: 'paid'
  },
  {
    id: '2',
    employeeId: '2',
    employeeName: 'Marie Martin',
    period: '2024-07',
    basicSalary: 4000,
    overtime: 0,
    bonuses: 300,
    deductions: 1000,
    netPay: 3300,
    status: 'paid'
  },
  {
    id: '3',
    employeeId: '3',
    employeeName: 'Pierre Durand',
    period: '2024-07',
    basicSalary: 3500,
    overtime: 100,
    bonuses: 0,
    deductions: 900,
    netPay: 2700,
    status: 'processed'
  }
];

export const performanceReviews: PerformanceReview[] = [
  {
    id: '1',
    employeeId: '1',
    employeeName: 'Jean Dupont',
    reviewPeriod: '2024 S1',
    reviewer: 'Marie Martin',
    overallRating: 4.5,
    goals: ['Améliorer la performance des applications', 'Mentorer les juniors', 'Apprendre React Native'],
    achievements: ['Migration réussie vers TypeScript', 'Formation de 3 développeurs juniors', 'Optimisation des performances de 40%'],
    areasForImprovement: ['Communication inter-équipes', 'Documentation technique'],
    comments: 'Excellent travail technique. Continue ses efforts en leadership.',
    status: 'completed',
    createdDate: '2024-07-01'
  },
  {
    id: '2',
    employeeId: '4',
    employeeName: 'Sophie Bernard',
    reviewPeriod: '2024 S1',
    reviewer: 'Marie Martin',
    overallRating: 4.2,
    goals: ['Améliorer les processus', 'Réduction des délais projets', 'Formation en agilité'],
    achievements: ['Réduction de 25% des délais', 'Mise en place de Scrum', 'Certification PMP obtenue'],
    areasForImprovement: ['Gestion du stress', 'Délégation'],
    comments: 'Très bon manager, résultats excellents sur les projets.',
    status: 'completed',
    createdDate: '2024-07-01'
  }
];